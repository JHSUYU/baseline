package org.apache.hadoop.hbase.client;

import edu.uva.liftlab.graphchecker.runtime.MessageDoors;
import java.lang.reflect.Field;
import org.apache.hadoop.hbase.HBaseTestingUtility;
import org.apache.hadoop.hbase.MiniHBaseCluster;
import org.apache.hadoop.hbase.master.HMaster;
import org.apache.hadoop.hbase.regionserver.HRegionServer;
import org.apache.hadoop.hbase.util.JVMClusterUtil;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;

/**
 * Records the original inherited JUnit test and MiniHBaseCluster lifecycle.
 * No workload steps or assertions are replaced.
 */
public class HBase01RecordingTest extends TestConnectionImplementation {
  private static final Object CLIENT = new Object();
  private static final String API = "TestConnectionImplementation.testMetaLookupThreadPoolCreated";
  private long workloadRequest;

  @BeforeAll
  public static void openRecordingWindow() throws Exception {
    MessageDoors.startRecording();
    MessageDoors.registerSource(CLIENT, "EXTERNAL_APP", "CLIENT", "hbase01-client", 0L);
    Field utilityField = TestConnectionImplementation.class.getDeclaredField("TEST_UTIL");
    utilityField.setAccessible(true);
    HBaseTestingUtility utility = (HBaseTestingUtility) utilityField.get(null);
    MiniHBaseCluster cluster = utility.getMiniHBaseCluster();
    int masterId = 0;
    for (JVMClusterUtil.MasterThread thread : cluster.getMasterThreads()) {
      HMaster master = thread.getMaster();
      MessageDoors.registerNode(master, "HBASE", "MASTER", "master-" + masterId++,
        master.getRpcServer(), master.getZooKeeper());
    }
    int serverId = 0;
    for (JVMClusterUtil.RegionServerThread thread : cluster.getRegionServerThreads()) {
      HRegionServer server = thread.getRegionServer();
      MessageDoors.registerNode(server, "HBASE", "REGION_SERVER", "region-server-" + serverId++,
        server.getRpcServer(), server.getRSRpcServices());
    }
    MessageDoors.registerSource(utility.getConnection(), "HBASE", "CLIENT",
      "hbase01-connection", 0L);
  }

  @BeforeEach
  public void openWorkloadRequest() {
    workloadRequest = MessageDoors.beginRequest(CLIENT, API);
  }

  @AfterEach
  public void closeRecordingWindow() {
    if (workloadRequest != 0L) {
      MessageDoors.endRequest(workloadRequest, API);
    }
    MessageDoors.stopRecording();
  }

  @AfterAll
  public static void closeRecordingWindowAfterClass() {
    MessageDoors.stopRecording();
  }
}
