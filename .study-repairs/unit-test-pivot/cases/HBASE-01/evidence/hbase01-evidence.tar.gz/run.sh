#!/usr/bin/env bash
set -euo pipefail

case_dir=/users/ZhenyuLi/baseline/.study-repairs/unit-test-pivot/cases/HBASE-01/work
hbase_dist=/users/ZhenyuLi/.baseline-deps/hbase-2.6.6
hadoop_dist=/users/ZhenyuLi/.baseline-deps/hadoop-2.10.0
graph_core=/users/ZhenyuLi/.graphchecker-builds/unit-test-hbase-8eac16949-68f7c3db8719.jar
java_bin=/usr/lib/jvm/java-8-openjdk-amd64/bin/java
test_name=org.apache.hadoop.hbase.client.HBase01RecordingTest#testMetaLookupThreadPoolCreated
static_dir="$case_dir/static-v3"
woven_dir="$case_dir/record-woven-v3"
graph_cp="$case_dir/planner-classes:$case_dir/catalog-overlay:$case_dir/graph-classes:$graph_core"

classpath="$case_dir/planner-classes:$case_dir/catalog-overlay:$case_dir/graph-classes:$woven_dir:$case_dir/adapter-generic:$case_dir/classes"
classpath="$classpath:/users/ZhenyuLi/.m2/repository/com/google/code/gson/gson/2.10.1/gson-2.10.1.jar"
classpath="$classpath:$hbase_dist/conf:$hbase_dist/lib/*:$hbase_dist/lib/client-facing-thirdparty/*"
classpath="$classpath:$hadoop_dist/share/hadoop/common/hadoop-common-2.10.0-tests.jar"
classpath="$classpath:$hadoop_dist/share/hadoop/common/lib/*:$graph_core"

case "${1:?stage required}" in
  static)
    mkdir -p "$static_dir" "$case_dir/woven-v3" "$woven_dir"
    exec timeout 360s /usr/bin/time -f 'ELAPSED_SECONDS=%e MAX_RSS_KB=%M' \
      "$java_bin" -Xmx4g \
      -Dcausynth.target.spec="$case_dir/target.yaml" \
      -Dcausynth.output.dir="$static_dir" \
      -Dcausynth.lineage.roots="$case_dir/scope:$hbase_dist/lib/hbase-client-2.6.6.jar" \
      -Dcausynth.loop.default.bound=8 \
      -cp "$graph_cp" \
      edu.uva.liftlab.graphchecker.GraphCheckerMain \
      -i "$case_dir/scope" -x "$classpath" -o "$case_dir/woven-v3"
    ;;
  weave)
    mkdir -p "$woven_dir"
    exec timeout 360s /usr/bin/time -f 'ELAPSED_SECONDS=%e MAX_RSS_KB=%M' \
      "$java_bin" -Xmx4g \
      -Dcausynth.trace.mode=region-state \
      -Dcausynth.region.skeletons="$static_dir/region_skeletons.jsonl.gz" \
      -Dcausynth.region.preserve.failure-target=true \
      -Dcausynth.lineage.roots="$case_dir/scope:$hbase_dist/lib/hbase-client-2.6.6.jar" \
      -Dcausynth.loop.default.bound=8 \
      -cp "$graph_cp" \
      edu.uva.liftlab.graphchecker.GraphCheckerMain \
      -i "$case_dir/scope" -x "$classpath" -o "$woven_dir"
    ;;
  run)
    suffix="${2:?unique run suffix required}"
    trace_dir="$case_dir/trace-$suffix"
    data_dir="$case_dir/data-$suffix"
    mkdir -p "$trace_dir" "$data_dir/tmp"
    fault_args=()
    if [[ -n "${3:-}" ]]; then
      fault_args+=("-Dcausynth.fault.trial=$3")
    fi
    export CAUSYNTH_TRACE_OUTPUT_DIR="$trace_dir"
    export HBASE_HOME="$hbase_dist"
    exec timeout 300s /usr/bin/time -f 'ELAPSED_SECONDS=%e MAX_RSS_KB=%M' \
      "$java_bin" -Xmx4g "${fault_args[@]}" \
      -Djava.io.tmpdir="$data_dir/tmp" \
      -Dtest.build.data.basedirectory="$data_dir" \
      -Dcausynth.trace.mode=region-state \
      -Dcausynth.trace.test="$test_name" \
      -Dcausynth.region.skeletons="$static_dir/region_skeletons.jsonl.gz" \
      -Dcausynth.region.preserve.failure-target=true \
      -cp "$classpath" \
      edu.uva.liftlab.graphchecker.runtime.JUnitMethodRunner \
      org.apache.hadoop.hbase.client.HBase01RecordingTest testMetaLookupThreadPoolCreated
    ;;
  aggregate)
    suffix="${2:?unique run suffix required}"
    trace_dir="$case_dir/trace-$suffix"
    output_dir="$trace_dir/aggregate"
    mkdir -p "$output_dir"
    exec timeout 120s /usr/bin/time -f 'ELAPSED_SECONDS=%e MAX_RSS_KB=%M' \
      "$java_bin" -Xmx4g -Dcausynth.loop.default.bound=8 -cp "$classpath" \
      edu.uva.liftlab.graphchecker.runtime.CausynthTraceRecorder \
      --trace-dir "$trace_dir" --test "$test_name" \
      --target "hbase01=$static_dir/candidate_dataflow_edges.jsonl.gz,$static_dir/static_scope_map.jsonl,$static_dir/region_skeletons.jsonl.gz,$output_dir" \
      --summary "$output_dir/targets.json"
    ;;
  *) echo "unknown stage: $1" >&2; exit 2 ;;
esac
