/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.hadoop.hbase.master.assignment;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import org.apache.hadoop.hbase.HBaseTestingUtility;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.RegionInfo;
import org.apache.hadoop.hbase.master.HMaster;
import org.apache.hadoop.hbase.master.procedure.MasterProcedureConstants;
import org.apache.hadoop.hbase.master.procedure.MasterProcedureEnv;
import org.apache.hadoop.hbase.master.procedure.MasterProcedureTestingUtility;
import org.apache.hadoop.hbase.procedure2.ProcedureExecutor;
import org.apache.hadoop.hbase.procedure2.ProcedureTestingUtility;
import org.apache.hadoop.hbase.regionserver.HRegion;
import org.apache.hadoop.hbase.regionserver.HRegionServer;
import org.apache.hadoop.hbase.testclassification.MasterTests;
import org.apache.hadoop.hbase.testclassification.MediumTests;
import org.apache.hadoop.hbase.util.Bytes;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;

@Tag(MasterTests.TAG)
@Tag(MediumTests.TAG)
public class TestTransitRegionStateProcedure {

  private static HBaseTestingUtility UTIL = new HBaseTestingUtility();

  private static byte[] CF = Bytes.toBytes("cf");

  private TableName tableName;

  @BeforeAll
  public static void setUpBeforeClass() throws Exception {
    UTIL.getConfiguration().setInt(MasterProcedureConstants.MASTER_PROCEDURE_THREADS, 1);
    UTIL.startMiniCluster(3);
    UTIL.getAdmin().balancerSwitch(false, true);
  }

  @AfterAll
  public static void tearDownAfterClass() throws Exception {
    UTIL.shutdownMiniCluster();
  }

  @BeforeEach
  public void setUp(TestInfo testInfo) throws IOException, InterruptedException {
    tableName = TableName.valueOf(testInfo.getTestMethod().get().getName());
    UTIL.createTable(tableName, CF);
    UTIL.waitTableAvailable(tableName);
  }

  private void resetProcExecutorTestingKillFlag() {
    ProcedureExecutor<MasterProcedureEnv> procExec =
      UTIL.getHBaseCluster().getMaster().getMasterProcedureExecutor();
    ProcedureTestingUtility.setKillAndToggleBeforeStoreUpdate(procExec, false);
    assertTrue(procExec.isRunning(), "expected executor to be running");
  }

  @AfterEach
  public void tearDown() throws IOException {
    resetProcExecutorTestingKillFlag();
    UTIL.deleteTable(tableName);
  }

  private void testRecoveryAndDoubleExcution(TransitRegionStateProcedure proc) throws Exception {
    HMaster master = UTIL.getHBaseCluster().getMaster();
    AssignmentManager am = master.getAssignmentManager();
    RegionStateNode regionNode = am.getRegionStates().getRegionStateNode(proc.getRegion());
    assertFalse(regionNode.isTransitionScheduled());
    regionNode.setProcedure(proc);
    assertTrue(regionNode.isTransitionScheduled());
    ProcedureExecutor<MasterProcedureEnv> procExec = master.getMasterProcedureExecutor();
    ProcedureTestingUtility.setKillAndToggleBeforeStoreUpdate(procExec, true);
    long procId = procExec.submitProcedure(proc);
    MasterProcedureTestingUtility.testRecoveryAndDoubleExecution(procExec, procId);
    regionNode = am.getRegionStates().getRegionStateNode(proc.getRegion());
    assertFalse(regionNode.isTransitionScheduled());
  }

  @Test
  public void testRecoveryAndDoubleExecutionMove() throws Exception {
    MasterProcedureEnv env =
      UTIL.getMiniHBaseCluster().getMaster().getMasterProcedureExecutor().getEnvironment();
    HRegion region = UTIL.getMiniHBaseCluster().getRegions(tableName).get(0);
    long openSeqNum = region.getOpenSeqNum();
    TransitRegionStateProcedure proc =
      TransitRegionStateProcedure.move(env, region.getRegionInfo(), null);
    testRecoveryAndDoubleExcution(proc);
    HRegion region2 = UTIL.getMiniHBaseCluster().getRegions(tableName).get(0);
    long openSeqNum2 = region2.getOpenSeqNum();
    // confirm that the region is successfully opened
    assertTrue(openSeqNum2 > openSeqNum);
  }

  @Test
  public void testRecoveryAndDoubleExecutionReopen() throws Exception {
    MasterProcedureEnv env =
      UTIL.getMiniHBaseCluster().getMaster().getMasterProcedureExecutor().getEnvironment();
    HRegionServer rs = UTIL.getRSForFirstRegionInTable(tableName);
    HRegion region = rs.getRegions(tableName).get(0);
    region.addReadRequestsCount(1);
    region.addWriteRequestsCount(2);
    long openSeqNum = region.getOpenSeqNum();
    TransitRegionStateProcedure proc =
      TransitRegionStateProcedure.reopen(env, region.getRegionInfo());
    testRecoveryAndDoubleExcution(proc);
    // should still be on the same RS
    HRegion region2 = rs.getRegions(tableName).get(0);
    long openSeqNum2 = region2.getOpenSeqNum();
    // confirm that the region is successfully opened
    assertTrue(openSeqNum2 > openSeqNum);
    // we check the available by scan after table created,
    // so the readRequestsCount should be 2 here
    assertEquals(2, region2.getReadRequestsCount());
    assertEquals(2, region2.getWriteRequestsCount());
  }

  @Test
  public void testRecoveryAndDoubleExecutionUnassignAndAssign() throws Exception {
    HMaster master = UTIL.getMiniHBaseCluster().getMaster();
    MasterProcedureEnv env = master.getMasterProcedureExecutor().getEnvironment();
    HRegion region = UTIL.getMiniHBaseCluster().getRegions(tableName).get(0);
    RegionInfo regionInfo = region.getRegionInfo();
    long openSeqNum = region.getOpenSeqNum();
    TransitRegionStateProcedure unassign = TransitRegionStateProcedure.unassign(env, regionInfo);
    testRecoveryAndDoubleExcution(unassign);
    AssignmentManager am = master.getAssignmentManager();
    assertTrue(am.getRegionStates().getRegionState(regionInfo).isClosed());

    TransitRegionStateProcedure assign = TransitRegionStateProcedure.assign(env, regionInfo, null);
    testRecoveryAndDoubleExcution(assign);

    HRegion region2 = UTIL.getMiniHBaseCluster().getRegions(tableName).get(0);
    long openSeqNum2 = region2.getOpenSeqNum();
    // confirm that the region is successfully opened
    assertTrue(openSeqNum2 > openSeqNum);
  }
}
